-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 07-Out-2025 às 01:13
-- Server version: 10.4.28-MariaDB
-- PHP version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dataset_article`
--

-- --------------------------------------------------------

--
-- Table structure for `llms`
--

CREATE TABLE `llms` (
  `id` int(11) NOT NULL,
  `model_name` varchar(255) NOT NULL,
  `lanchain_class` varchar(100) NOT NULL,
  `type` enum('open-source','premium') NOT NULL,
  `is_active` tinyint(4) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `temperature` float DEFAULT 0.2
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `llms`
--

INSERT INTO `llms` (`id`, `model_name`, `lanchain_class`, `type`, `is_active`, `created_at`, `updated_at`, `temperature`) VALUES
(1, 'gpt-4.1', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-14 11:49:17', 0.1),
(2, 'gpt-4.1-mini', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-14 11:49:19', 0.1),
(3, 'gpt-4.1-nano', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-14 11:49:22', 0.1),
(4, 'gpt-4o', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-14 11:49:24', 0.1),
(5, 'gpt-4o-mini', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-14 11:49:26', 0.1),
(6, 'o3', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-11 22:04:24', 1),
(7, 'o4-mini', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-11 22:04:27', 1),
(8, 'o1', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-11 22:04:30', 1),
(9, 'o1-mini', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-11 22:04:34', 1),
(10, 'o1-preview', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-11 22:04:38', 1),
(11, 'o3-mini', 'CustomChatOpenAI', 'premium', 1, '2025-06-11 22:03:28', '2025-06-11 22:04:42', 1),
(12, 'deepseek-r1-distill-llama-70b', 'CustomChatGroq', 'open-source', 1, '2025-06-12 14:42:44', NULL, 1),
(13, 'deepseek-chat', 'CustomDeepSeekChat', 'open-source', 1, '2025-06-12 14:42:44', '2025-06-14 11:49:28', 0.1),
(14, 'claude-sonnet-4-20250514', 'CustomClaudeChat', 'premium', 1, '2025-06-12 16:13:43', '2025-06-14 11:49:31', 0.1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `llms`
--
ALTER TABLE `llms`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `llms`
--
ALTER TABLE `llms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
