-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 07-Out-2025 às 01:14
-- Server version: 10.4.28-MariaDB
-- PHP version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dataset_article`
--

-- --------------------------------------------------------

--
-- Table structure for `rag`
--

CREATE TABLE `rag` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `assignment_id` int(11) NOT NULL,
  `collection` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rag`
--

INSERT INTO `rag` (`id`, `teacher_id`, `assignment_id`, `collection`, `name`, `subject`, `start_date`, `end_date`, `is_active`, `created_at`, `updated_at`) VALUES
(3, 4, 7, 'QO6SaO4MbnITXdWn', 'EDA 1 - Arrays Estaticos', 'C++ Ficha Formativa 1', '2025-02-03 14:00:00', '2025-07-31 20:00:00', 1, '2025-02-05 14:31:36', '2025-07-01 07:32:33'),
(4, 4, 8, 'uIEg6TSqWeG19Zvb', 'EDA 2 - Apontadores', 'C++ Ficha Formativa 2', '2025-02-03 14:00:00', '2025-07-31 20:00:00', 1, '2025-06-12 16:53:23', NULL),
(5, 4, 9, 'lo3ahUJpohayesZP', 'EDA 3 - Algoritmos e Arvores', 'C++ Ficha Formativa 3', '2025-02-03 14:00:00', '2025-07-31 20:00:00', 1, '2025-06-12 16:57:11', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rag`
--
ALTER TABLE `rag`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `assignment_id` (`assignment_id`),
  ADD UNIQUE KEY `collection` (`collection`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rag`
--
ALTER TABLE `rag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rag`
--
ALTER TABLE `rag`
  ADD CONSTRAINT `fk_rag_assignment` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
