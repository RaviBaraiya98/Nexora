-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 07-Out-2025 às 01:14
-- Server version: 10.4.28-MariaDB
-- PHP version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dataset_article`
--

-- --------------------------------------------------------

--
-- Table structure for `ucs`
--

CREATE TABLE `ucs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `year` tinyint(4) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `semester` tinyint(4) NOT NULL CHECK (`semester` in (1,2)),
  `is_active` tinyint(4) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ucs`
--

INSERT INTO `ucs` (`id`, `name`, `year`, `course_name`, `semester`, `is_active`, `created_at`, `updated_at`) VALUES
(8, 'Estruturas de Dados e Algoritmos', 1, 'Licenciatura em Enganharia Informática', 2, 1, '2025-02-01 10:35:25', '2025-07-31 10:35:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ucs`
--
ALTER TABLE `ucs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ucs`
--
ALTER TABLE `ucs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
