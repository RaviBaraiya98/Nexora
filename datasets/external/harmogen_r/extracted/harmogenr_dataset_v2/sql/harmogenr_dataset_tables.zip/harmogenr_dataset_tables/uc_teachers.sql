-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 07-Out-2025 às 01:14
-- Server version: 10.4.28-MariaDB
-- PHP version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dataset_article`
--

-- --------------------------------------------------------

--
-- Table structure for `uc_teachers`
--

CREATE TABLE `uc_teachers` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `uc_school_year_id` int(11) NOT NULL,
  `is_active` tinyint(4) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uc_teachers`
--

INSERT INTO `uc_teachers` (`id`, `teacher_id`, `uc_school_year_id`, `is_active`, `created_at`, `updated_at`) VALUES
(9, 4, 5, 1, '2025-01-14 10:39:09', NULL),
(10, 10, 5, 1, '2025-01-14 10:39:17', NULL),
(11, 11, 5, 1, '2025-01-14 10:39:21', NULL),
(13, 224, 5, 1, '2025-02-19 22:42:19', NULL),
(14, 225, 5, 1, '2025-02-19 22:42:19', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `uc_teachers`
--
ALTER TABLE `uc_teachers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `uc_school_year_id` (`uc_school_year_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `uc_teachers`
--
ALTER TABLE `uc_teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `uc_teachers`
--
ALTER TABLE `uc_teachers`
  ADD CONSTRAINT `fk_uc_teachers_uc_school_year` FOREIGN KEY (`uc_school_year_id`) REFERENCES `uc_school_year` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
